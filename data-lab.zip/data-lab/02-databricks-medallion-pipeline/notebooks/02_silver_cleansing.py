# Databricks notebook source
# MAGIC %md
# MAGIC # 02 · Silver — Cleansing & Validation
# MAGIC
# MAGIC **Goal:** turn messy bronze data into trusted, typed tables.
# MAGIC
# MAGIC | Data-quality issue found in bronze | Fix applied |
# MAGIC |---|---|
# MAGIC | Exact duplicate trip rows | `dropDuplicates(["trip_id"])` |
# MAGIC | City in mixed case / padded spaces (`HYDERABAD`, ` Pune `) | `trim` + `initcap` |
# MAGIC | Status in mixed case (`COMPLETED`) | `lower` + `trim` |
# MAGIC | All columns are strings | Cast to timestamp / double / int |
# MAGIC | Missing pickup time, negative distance, completed trip with no fare | Routed to **quarantine** table with a reason |
# MAGIC
# MAGIC Bad rows are **never silently dropped** — they go to `silver_trips_quarantine` so they can be reviewed.

# COMMAND ----------

dbutils.widgets.text("catalog", "workspace", "Catalog")
dbutils.widgets.text("schema", "ride_analytics", "Schema")
spark.sql(f"USE CATALOG {dbutils.widgets.get('catalog')}")
spark.sql(f"USE SCHEMA {dbutils.widgets.get('schema')}")

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# MAGIC %md ## 1. Standardise & cast trips

# COMMAND ----------

bronze_trips = spark.table("bronze_trips")

typed_trips = (
    bronze_trips
    .dropDuplicates(["trip_id"])
    .select(
        F.trim("trip_id").alias("trip_id"),
        F.trim("driver_id").alias("driver_id"),
        F.initcap(F.trim("city")).alias("city"),
        # try_* functions return NULL instead of failing on bad values (safe under ANSI mode)
        F.expr("try_to_timestamp(trim(pickup_ts), 'yyyy-MM-dd HH:mm:ss')").alias("pickup_ts"),
        F.expr("try_cast(distance_km AS DOUBLE)").alias("distance_km"),
        F.expr("try_cast(duration_min AS INT)").alias("duration_min"),
        F.expr("try_cast(fare_amount AS DECIMAL(10,2))").alias("fare_amount"),
        F.trim("payment_mode").alias("payment_mode"),
        F.lower(F.trim("trip_status")).alias("trip_status"),
        F.expr("try_cast(rating AS INT)").alias("rating"),
        "_ingested_at",
    )
)

# COMMAND ----------

# MAGIC %md ## 2. Apply validation rules

# COMMAND ----------

dq_reason = (
    F.when(F.col("pickup_ts").isNull(), "missing_pickup_ts")
    .when(F.col("distance_km").isNull() | (F.col("distance_km") <= 0), "invalid_distance")
    .when((F.col("trip_status") == "completed") & F.col("fare_amount").isNull(), "missing_fare")
    .when(~F.col("trip_status").isin("completed", "cancelled"), "unknown_status")
)

validated = typed_trips.withColumn("dq_reason", dq_reason)

good_trips = (
    validated.filter(F.col("dq_reason").isNull())
    .drop("dq_reason")
    .withColumn("pickup_date", F.to_date("pickup_ts"))
    .withColumn("pickup_hour", F.hour("pickup_ts"))
)
bad_trips = validated.filter(F.col("dq_reason").isNotNull())

# COMMAND ----------

# MAGIC %md ## 3. Write Silver tables

# COMMAND ----------

good_trips.write.format("delta").mode("overwrite").option("overwriteSchema", True).saveAsTable("silver_trips")
bad_trips.write.format("delta").mode("overwrite").option("overwriteSchema", True).saveAsTable("silver_trips_quarantine")

silver_drivers = (
    spark.table("bronze_drivers")
    .dropDuplicates(["driver_id"])
    .select(
        F.trim("driver_id").alias("driver_id"),
        F.initcap(F.trim("driver_name")).alias("driver_name"),
        F.initcap(F.trim("city")).alias("city"),
        F.trim("vehicle_type").alias("vehicle_type"),
        F.expr("try_to_timestamp(joined_date, 'yyyy-MM-dd')").cast("date").alias("joined_date"),
    )
)
silver_drivers.write.format("delta").mode("overwrite").option("overwriteSchema", True).saveAsTable("silver_drivers")

# COMMAND ----------

# MAGIC %md ## 4. Data-quality summary

# COMMAND ----------

bronze_count = bronze_trips.count()
silver_count = spark.table("silver_trips").count()
quarantine_count = spark.table("silver_trips_quarantine").count()

print(f"Bronze rows          : {bronze_count}")
print(f"Duplicates removed   : {bronze_count - typed_trips.count()}")
print(f"Silver (clean) rows  : {silver_count}")
print(f"Quarantined rows     : {quarantine_count}")

display(spark.table("silver_trips_quarantine").groupBy("dq_reason").count())
