# Databricks notebook source
# MAGIC %md
# MAGIC # 01 · Bronze — Raw Ingestion
# MAGIC
# MAGIC **Goal:** land the raw CSV files into Delta tables *as-is*, adding only audit columns.
# MAGIC
# MAGIC | Input (Volume) | Output (Delta table) |
# MAGIC |---|---|
# MAGIC | `trips.csv` | `bronze_trips` |
# MAGIC | `drivers.csv` | `bronze_drivers` |
# MAGIC
# MAGIC Bronze rule: **no cleaning here**. Every column is read as a string so a bad value can never fail the load.

# COMMAND ----------

# MAGIC %md ## Configuration

# COMMAND ----------

dbutils.widgets.text("catalog", "workspace", "Catalog")
dbutils.widgets.text("schema", "ride_analytics", "Schema")
dbutils.widgets.text("volume", "raw", "Volume")

catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")
volume = dbutils.widgets.get("volume")

raw_path = f"/Volumes/{catalog}/{schema}/{volume}"
spark.sql(f"USE CATALOG {catalog}")
spark.sql(f"USE SCHEMA {schema}")
print(f"Reading raw files from: {raw_path}")

# COMMAND ----------

# MAGIC %md ## Ingest helper

# COMMAND ----------

from pyspark.sql import functions as F


def ingest_csv_to_bronze(file_name: str, table_name: str) -> int:
    """Read a CSV as all-string columns, add audit columns, overwrite a bronze Delta table."""
    df = (
        spark.read.option("header", True)
        .option("inferSchema", False)  # keep everything as string in bronze
        .csv(f"{raw_path}/{file_name}")
        .withColumn("_source_file", F.col("_metadata.file_path"))
        .withColumn("_ingested_at", F.current_timestamp())
    )
    df.write.format("delta").mode("overwrite").option("overwriteSchema", True).saveAsTable(table_name)
    count = spark.table(table_name).count()
    print(f"{table_name}: {count} rows loaded")
    return count

# COMMAND ----------

# MAGIC %md ## Load

# COMMAND ----------

ingest_csv_to_bronze("trips.csv", "bronze_trips")
ingest_csv_to_bronze("drivers.csv", "bronze_drivers")

# COMMAND ----------

# MAGIC %md ## Peek at the raw data — note the messy values we will fix in Silver

# COMMAND ----------

display(
    spark.table("bronze_trips")
    .groupBy("city")
    .count()
    .orderBy("city")
)
