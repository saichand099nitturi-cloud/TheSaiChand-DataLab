# Databricks notebook source
# MAGIC %md
# MAGIC # 03 · Gold — Business Aggregates
# MAGIC
# MAGIC **Goal:** build small, report-ready tables from Silver.
# MAGIC
# MAGIC | Gold table | Grain | Answers |
# MAGIC |---|---|---|
# MAGIC | `gold_daily_city_revenue` | date × city | How much did each city earn each day? |
# MAGIC | `gold_driver_performance` | driver | Who are the top earners, and who cancels most? |
# MAGIC | `gold_payment_mix` | payment mode | How do riders pay? |

# COMMAND ----------

dbutils.widgets.text("catalog", "workspace", "Catalog")
dbutils.widgets.text("schema", "ride_analytics", "Schema")
spark.sql(f"USE CATALOG {dbutils.widgets.get('catalog')}")
spark.sql(f"USE SCHEMA {dbutils.widgets.get('schema')}")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

trips = spark.table("silver_trips")
drivers = spark.table("silver_drivers")
completed = trips.filter(F.col("trip_status") == "completed")

# COMMAND ----------

# MAGIC %md ## Gold 1 — Daily revenue per city

# COMMAND ----------

gold_daily_city_revenue = (
    completed.groupBy("pickup_date", "city")
    .agg(
        F.count("*").alias("completed_trips"),
        F.round(F.sum("fare_amount"), 2).alias("revenue"),
        F.round(F.avg("distance_km"), 2).alias("avg_distance_km"),
        F.round(F.sum("fare_amount") / F.sum("distance_km"), 2).alias("revenue_per_km"),
    )
    .orderBy("pickup_date", "city")
)
gold_daily_city_revenue.write.format("delta").mode("overwrite").option("overwriteSchema", True).saveAsTable("gold_daily_city_revenue")

# COMMAND ----------

# MAGIC %md ## Gold 2 — Driver performance

# COMMAND ----------

gold_driver_performance = (
    trips.groupBy("driver_id")
    .agg(
        F.count("*").alias("total_trips"),
        F.sum(F.when(F.col("trip_status") == "completed", 1).otherwise(0)).alias("completed_trips"),
        F.sum(F.when(F.col("trip_status") == "cancelled", 1).otherwise(0)).alias("cancelled_trips"),
        F.round(F.sum(F.when(F.col("trip_status") == "completed", F.col("fare_amount"))), 2).alias("total_earnings"),
        F.round(F.avg("rating"), 2).alias("avg_rating"),
    )
    .withColumn("cancellation_rate_pct", F.round(100 * F.col("cancelled_trips") / F.col("total_trips"), 1))
    .join(drivers, "driver_id", "left")
    .select(
        "driver_id", "driver_name", "city", "vehicle_type",
        "total_trips", "completed_trips", "cancelled_trips",
        "cancellation_rate_pct", "total_earnings", "avg_rating",
    )
)
gold_driver_performance.write.format("delta").mode("overwrite").option("overwriteSchema", True).saveAsTable("gold_driver_performance")

# COMMAND ----------

# MAGIC %md ## Gold 3 — Payment mix

# COMMAND ----------

gold_payment_mix = (
    completed.groupBy("payment_mode")
    .agg(F.count("*").alias("trips"), F.round(F.sum("fare_amount"), 2).alias("revenue"))
    .withColumn("share_pct", F.round(100 * F.col("trips") / F.sum("trips").over(Window.partitionBy()), 1))
    .orderBy(F.desc("revenue"))
)
gold_payment_mix.write.format("delta").mode("overwrite").option("overwriteSchema", True).saveAsTable("gold_payment_mix")

# COMMAND ----------

# MAGIC %md ## Results

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Revenue by city (all days)
# MAGIC SELECT city, SUM(completed_trips) AS trips, ROUND(SUM(revenue), 2) AS revenue
# MAGIC FROM gold_daily_city_revenue
# MAGIC GROUP BY city
# MAGIC ORDER BY revenue DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Top 5 drivers by earnings
# MAGIC SELECT driver_name, city, vehicle_type, completed_trips, total_earnings, avg_rating
# MAGIC FROM gold_driver_performance
# MAGIC ORDER BY total_earnings DESC
# MAGIC LIMIT 5;

# COMMAND ----------

display(spark.table("gold_payment_mix"))
