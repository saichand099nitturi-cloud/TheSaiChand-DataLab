# 02 · Ride-Hailing Medallion Pipeline on Databricks

A **PySpark + Delta Lake** pipeline that takes messy ride-hailing trip data through the **Bronze → Silver → Gold** medallion architecture on Databricks, with data-quality checks and a quarantine table.

![Databricks](https://img.shields.io/badge/Databricks-PySpark-FF3621?logo=databricks&logoColor=white)
![Delta Lake](https://img.shields.io/badge/Delta%20Lake-tables-00ADD4)
![Unity Catalog](https://img.shields.io/badge/Unity%20Catalog-Volumes-blue)

---

## Business scenario

A ride-hailing startup operates in 5 Indian cities. Trip data arrives as daily CSV exports from the app — and it's messy: duplicate rows, inconsistent city names, missing timestamps, negative distances. The ops team needs **clean, trusted numbers** on city revenue, driver performance and payment mix.

## Architecture

```
  CSV files            BRONZE                 SILVER                       GOLD
 (UC Volume)        (raw, as-is)        (clean, typed, valid)      (business aggregates)
┌────────────┐    ┌──────────────┐    ┌──────────────────────┐    ┌─────────────────────────┐
│ trips.csv  │───▶│ bronze_trips │───▶│ silver_trips         │───▶│ gold_daily_city_revenue │
│            │    │              │ └─▶│ silver_trips_        │    │ gold_driver_performance │
│ drivers.csv│───▶│bronze_drivers│───▶│   quarantine         │ ┌─▶│ gold_payment_mix        │
└────────────┘    └──────────────┘    │ silver_drivers ──────┼─┘ └─────────────────────────┘
                                      └──────────────────────┘
```

## Dataset

| File | Rows | Notes |
|---|---|---|
| [`data/trips.csv`](data/trips.csv) | 612 | Jul–Sep 2025 trips, **with deliberate data-quality defects** |
| [`data/drivers.csv`](data/drivers.csv) | 30 | Driver master: city, vehicle type (Auto / Mini / Sedan / Bike) |

## Notebooks

| # | Notebook | What it does |
|---|---|---|
| 1 | [`01_bronze_ingestion.py`](notebooks/01_bronze_ingestion.py) | Reads CSVs as strings, adds `_source_file` + `_ingested_at` audit columns, writes Delta |
| 2 | [`02_silver_cleansing.py`](notebooks/02_silver_cleansing.py) | De-dupes, standardises text, safely casts types, applies validation rules, quarantines bad rows |
| 3 | [`03_gold_aggregations.py`](notebooks/03_gold_aggregations.py) | Builds 3 report-ready Gold tables + SQL result cells |

### Data-quality rules (Silver)

| Problem | Handling |
|---|---|
| 12 exact duplicate trips | Removed with `dropDuplicates(["trip_id"])` |
| City as `HYDERABAD`, `pune`, `" Chennai "` | `trim` + `initcap` |
| Status as `COMPLETED` | `lower` + `trim` |
| Missing pickup time (4) | → quarantine `missing_pickup_ts` |
| Negative distance (5) | → quarantine `invalid_distance` |
| Completed trip with no fare (8) | → quarantine `missing_fare` |

Casting uses `try_cast` / `try_to_timestamp` so a bad value becomes `NULL` and gets quarantined instead of crashing the job (important on serverless, where ANSI mode is on).

## How to run

Works on **Databricks Free Edition** or any Unity Catalog workspace.

1. Create the schema and a volume (in a SQL cell or the SQL editor):
   ```sql
   CREATE SCHEMA IF NOT EXISTS workspace.ride_analytics;
   CREATE VOLUME IF NOT EXISTS workspace.ride_analytics.raw;
   ```
2. **Catalog → workspace → ride_analytics → raw → Upload to this volume** → upload both CSVs from `data/`.
3. **Workspace → Import** → upload the three `.py` files from `notebooks/` (they import as notebooks).
4. Run notebooks **01 → 02 → 03** on serverless compute. Change the `catalog` / `schema` widgets if yours differ.

## Results

| Metric | Value |
|---|---|
| Rows in Bronze | 612 |
| Clean rows in Silver | 583 |
| Quarantined | 17 (8 missing fare, 5 bad distance, 4 missing time) |
| Completed-trip revenue | ₹1,22,303 across 522 trips |
| Top city | Mumbai — ₹36,600 |
| Payment mix | UPI 26% · Cash 26% · Wallet 26% · Card 22% |

## What I'd add next

- Incremental ingestion with **Auto Loader** instead of full overwrite
- **Delta Live Tables / Lakeflow** expectations for the validation rules
- A **Databricks Job** to schedule 01 → 02 → 03 as one workflow
- A Databricks SQL dashboard on the Gold tables
