# 03 · EdTech Enrollment Analytics on Microsoft Fabric

An end-to-end **Microsoft Fabric** project: raw CSVs land in a **Lakehouse**, a **PySpark notebook** builds a star schema as Delta tables, the **SQL analytics endpoint** exposes reporting views, and a **Direct Lake** Power BI report sits on top.

![Microsoft Fabric](https://img.shields.io/badge/Microsoft%20Fabric-Lakehouse-117865)
![PySpark](https://img.shields.io/badge/PySpark-notebook-E25A1C?logo=apachespark&logoColor=white)
![Power BI](https://img.shields.io/badge/Power%20BI-Direct%20Lake-F2C811?logo=powerbi&logoColor=black)

---

## Business scenario

An online data-skills academy sells 6 courses (SQL, Power BI, PySpark, ADF, Fabric, Python). Leadership wants one place to see **which courses earn the most, which marketing channels bring paying students, and how many students actually finish.**

## Architecture

```
┌──────────────────────── Fabric Workspace ────────────────────────┐
│                                                                  │
│  Lakehouse: lh_edtech                                            │
│  ┌──────────────┐   notebook    ┌──────────────────────────┐     │
│  │ Files/raw/   │──────────────▶│ Tables/ (Delta)          │     │
│  │  students    │ nb_build_     │  dim_student  dim_course │     │
│  │  courses     │ star_schema   │  dim_date fact_enrollment│     │
│  │  enrollments │               └────────────┬─────────────┘     │
│  └──────────────┘                            │                   │
│                              SQL analytics endpoint (views)      │
│                                              │                   │
│                              Semantic model (Direct Lake)        │
│                                              │                   │
│                                     Power BI report              │
└──────────────────────────────────────────────────────────────────┘
```

## Star schema

```
 dim_student ──┐                ┌── dim_course
 (student_id)  │                │   (course_id)
               ▼                ▼
            ┌──────────────────────┐
            │   fact_enrollment    │
            └──────────┬───────────┘
                       │ date_key
                   dim_date
```

| Table | Rows | Key columns |
|---|---|---|
| `dim_student` | 150 | city, acquisition_source (YouTube, Instagram, Referral, Website, LinkedIn) |
| `dim_course` | 6 | track, price_inr, derived `price_band` |
| `dim_date` | generated | date_key, year_month, day_name, is_weekend |
| `fact_enrollment` | 223 | amount_paid_inr, discount_inr, completion_pct, status |

## Repo contents

| Path | What it is |
|---|---|
| [`data/`](data/) | 3 raw CSVs |
| [`notebooks/nb_build_star_schema.ipynb`](notebooks/nb_build_star_schema.ipynb) | Explicit schemas → dims + fact → referential-integrity check → Delta tables |
| [`sql/analytics_views.sql`](sql/analytics_views.sql) | 2 reporting views + 4 business queries for the SQL analytics endpoint |

## How to run (Fabric trial or capacity)

1. **Create a workspace** → **New item → Lakehouse** → name it `lh_edtech`.
2. In the Lakehouse, **Files → New subfolder `raw`** → **Upload** the 3 CSVs from `data/`.
3. **Workspace → Import → Notebook → From this computer** → choose `nb_build_star_schema.ipynb`. Open it, attach `lh_edtech` as the default lakehouse, **Run all**.
4. Switch the Lakehouse to its **SQL analytics endpoint** → **New SQL query** → run `sql/analytics_views.sql`.
5. **New semantic model** from the endpoint → select the 4 tables → create relationships (`student_id`, `course_id`, `date_key`, all many-to-one from the fact) → mark `dim_date` as the date table → build a report.

### Suggested DAX measures

```DAX
Revenue          = SUM ( fact_enrollment[amount_paid_inr] )
Enrollments      = COUNTROWS ( fact_enrollment )
Students         = DISTINCTCOUNT ( fact_enrollment[student_id] )
Completion Rate  = DIVIDE ( CALCULATE ( [Enrollments], fact_enrollment[status] = "Completed" ), [Enrollments] )
Avg Revenue per Student = DIVIDE ( [Revenue], [Students] )
Revenue MTD      = TOTALMTD ( [Revenue], dim_date[date] )
```

## Key results (sample data)

- **Total revenue:** ₹14,01,602 from 223 enrollments (Jan–Oct 2025)
- **Top course:** Microsoft Fabric Data Engineering — ₹4,19,454 (30% of revenue)
- **Best channel:** Referral (₹3,13,148), with YouTube close behind (₹2,95,828)
- **Completion rate:** 28% of enrollments completed
- **Cross-sell:** 39% of students bought more than one course

## What I'd add next

- A **Data Pipeline** to copy new CSVs into `Files/raw` and trigger the notebook on a schedule
- Incremental loads with Delta `MERGE` instead of full overwrite
- A **Warehouse** layer for business-user T-SQL access
