/* =========================================================
   analytics_views.sql
   Run in the Lakehouse **SQL analytics endpoint**
   (Lakehouse → switch to "SQL analytics endpoint" → New SQL query).
   Creates reporting views over the Delta tables built by
   nb_build_star_schema, then answers 4 business questions.
   Tip: CREATE VIEW must be alone in its batch — if the editor
   complains, run each block between the GO lines separately.
   ========================================================= */

/* View 1: one wide, report-friendly row per enrollment */
CREATE OR ALTER VIEW dbo.vw_enrollment_detail AS
SELECT
    f.enrollment_id,
    f.enroll_date,
    d.year_month,
    d.day_name,
    s.student_id,
    s.student_name,
    s.city,
    s.acquisition_source,
    c.course_name,
    c.track,
    c.price_band,
    f.amount_paid_inr,
    f.discount_inr,
    f.completion_pct,
    f.status
FROM dbo.fact_enrollment f
JOIN dbo.dim_student s ON s.student_id = f.student_id
JOIN dbo.dim_course  c ON c.course_id  = f.course_id
JOIN dbo.dim_date    d ON d.date_key   = f.date_key;
GO

/* View 2: course scorecard */
CREATE OR ALTER VIEW dbo.vw_course_scorecard AS
SELECT
    c.course_name,
    c.track,
    COUNT(*)                                                 AS enrollments,
    SUM(f.amount_paid_inr)                                   AS revenue_inr,
    AVG(CAST(f.completion_pct AS DECIMAL(5,2)))              AS avg_completion_pct,
    100.0 * SUM(CASE WHEN f.status = 'Completed' THEN 1 ELSE 0 END) / COUNT(*) AS completion_rate_pct,
    100.0 * SUM(CASE WHEN f.status = 'Dropped'   THEN 1 ELSE 0 END) / COUNT(*) AS dropout_rate_pct
FROM dbo.fact_enrollment f
JOIN dbo.dim_course c ON c.course_id = f.course_id
GROUP BY c.course_name, c.track;
GO

/* Q1. Which course earns the most and keeps students engaged? */
SELECT * FROM dbo.vw_course_scorecard ORDER BY revenue_inr DESC;

/* Q2. Which marketing channel brings the most paying students? */
SELECT
    acquisition_source,
    COUNT(DISTINCT student_id)   AS students,
    COUNT(*)                     AS enrollments,
    SUM(amount_paid_inr)         AS revenue_inr
FROM dbo.vw_enrollment_detail
GROUP BY acquisition_source
ORDER BY revenue_inr DESC;

/* Q3. Monthly enrollment & revenue trend */
SELECT
    year_month,
    COUNT(*)             AS enrollments,
    SUM(amount_paid_inr) AS revenue_inr,
    SUM(discount_inr)    AS discount_given_inr
FROM dbo.vw_enrollment_detail
GROUP BY year_month
ORDER BY year_month;

/* Q4. Cross-sell: how many students take more than one course? */
WITH per_student AS (
    SELECT student_id, COUNT(*) AS courses_taken
    FROM dbo.fact_enrollment
    GROUP BY student_id
)
SELECT
    courses_taken,
    COUNT(*) AS students
FROM per_student
GROUP BY courses_taken
ORDER BY courses_taken;
