# 01 · Retail Sales Analytics with SQL Server

A small, self-contained **T-SQL** project that models a retail chain's sales and answers 10 real business questions using joins, CTEs and window functions.

![SQL Server](https://img.shields.io/badge/SQL%20Server-T--SQL-CC2927?logo=microsoftsqlserver&logoColor=white)
![Level](https://img.shields.io/badge/level-beginner%20→%20intermediate-blue)

---

## Business scenario

A grocery & household retail chain has **5 stores** across Hyderabad, Bengaluru, Chennai, Mumbai and Pune. Management wants answers to questions like:

- Which store and category drive the most revenue?
- How is revenue trending month over month?
- Who are our most valuable customers, and how do they segment?
- How much revenue are discounts costing us?

## Data model

```
              ┌──────────────┐
              │   Stores     │
              └──────┬───────┘
                     │ StoreID
┌──────────────┐  ┌──┴───────────┐  ┌──────────────┐
│  Customers   ├──┤    Sales     ├──┤   Products   │
└──────────────┘  │   (fact)     │  └──────────────┘
     CustomerID   └──────────────┘   ProductID
```

| Table | Rows | Description |
|---|---|---|
| `Stores` | 5 | Store name, city, state |
| `Products` | 12 | 4 categories: Grocery, Beverages, Household, Personal Care |
| `Customers` | 40 | Customer name, city, join date |
| `Sales` | 400 | One line per sale in 2025 — qty, price, discount, **computed `NetAmount`** |

## How to run

1. Open **SSMS** (or Azure Data Studio) connected to any SQL Server 2016+ instance.
2. Run the scripts in order:

| # | Script | What it does |
|---|---|---|
| 1 | [`sql/01_create_schema.sql`](sql/01_create_schema.sql) | Creates `RetailSalesDB`, tables, PK/FK/CHECK constraints, computed column, indexes |
| 2 | [`sql/02_load_sample_data.sql`](sql/02_load_sample_data.sql) | Inserts all sample data + row-count check |
| 3 | [`sql/03_business_queries.sql`](sql/03_business_queries.sql) | 10 analysis queries + a reporting view |

All scripts are re-runnable.

## Questions answered

| # | Question | SQL concepts |
|---|---|---|
| Q1 | Overall KPIs: revenue, orders, units, AOV | Aggregates |
| Q2 | Revenue by store | `JOIN`, `GROUP BY` |
| Q3 | Category revenue share % | Window function over an aggregate |
| Q4 | Month-over-month growth | CTE, `LAG()`, `NULLIF` |
| Q5 | Running total revenue | `SUM() OVER (ROWS …)` |
| Q6 | Top 3 products per category | `RANK() OVER (PARTITION BY …)` |
| Q7 | Top 10 customers | `TOP`, joins |
| Q8 | Customer segmentation (Platinum → Bronze) | `NTILE()`, `CASE` |
| Q9 | Cost of discounts per store | Conditional aggregation |
| Q10 | Weekday vs weekend pattern | `DATENAME`, `CASE` |
| Bonus | `vw_SalesDetail` reporting view | `CREATE OR ALTER VIEW` |

## Key results (sample data)

- **Net revenue 2025:** ₹1,74,893 from 400 orders
- **Top store:** Anna Nagar (Chennai) — ₹55,172, about 32% of total revenue
- **Smallest store:** Hinjewadi (Pune) — ₹13,374, a candidate for a local promotion

## What I'd add next

- Load data from CSV with `BULK INSERT` instead of `INSERT` scripts
- Add a `DimDate` table and stored procedures for incremental loads
- Connect `vw_SalesDetail` to Power BI for a dashboard
