# Data Lab 🧪

Hands-on data engineering projects by **Bharath** — trainer & BI consultant at [RealDataCloud](https://realdatacloud.com).

Each project is small, self-contained and runnable: sample data is included, every folder has its own README with the business problem, architecture, how to run it, and results.

## Projects

| # | Project | Stack | What it shows |
|---|---|---|---|
| 01 | [Retail Sales Analytics](01-sql-retail-sales-analytics/) | SQL Server · T-SQL | Schema design with constraints, CTEs, window functions (`RANK`, `LAG`, `NTILE`, running totals), customer segmentation |
| 02 | [Ride-Hailing Medallion Pipeline](02-databricks-medallion-pipeline/) | Databricks · PySpark · Delta Lake · Unity Catalog | Bronze → Silver → Gold, data-quality rules, quarantine table, de-duplication, ANSI-safe casting |
| 03 | [EdTech Enrollment Analytics](03-fabric-lakehouse-analytics/) | Microsoft Fabric · Lakehouse · PySpark · SQL endpoint · Power BI | Star schema in a Lakehouse, date dimension, referential-integrity checks, reporting views, Direct Lake DAX |

## Repo structure

```
data-lab/
├── 01-sql-retail-sales-analytics/
│   └── sql/                       # create → load → analyse
├── 02-databricks-medallion-pipeline/
│   ├── data/                      # raw CSVs (with deliberate defects)
│   └── notebooks/                 # bronze · silver · gold
└── 03-fabric-lakehouse-analytics/
    ├── data/                      # raw CSVs
    ├── notebooks/                 # star-schema build notebook
    └── sql/                       # SQL analytics endpoint views
```

## Skills covered

`SQL` `T-SQL` `Data Modeling` `Star Schema` `PySpark` `Delta Lake` `Databricks` `Unity Catalog` `Medallion Architecture` `Data Quality` `Microsoft Fabric` `Lakehouse` `Power BI` `DAX`

---

All datasets are synthetic and generated for learning purposes.
